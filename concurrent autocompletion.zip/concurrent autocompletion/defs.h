#define MAX_WORD_LEN 64
#define LETTERS 26
#define CHAR_TO_INDEX(c) ((int)c - (int)'a')	//pobrinuti se da svi budu lowercase da bi radilo

typedef struct trie_node
{
	char c;
	int term;			//oznaka za kraj reci
	int subwords;		//broj reci u podstablu, ne racunajuci sebe
	struct trie_node *parent;
	struct trie_node *children[LETTERS];
} trie_node;

typedef struct search_result
{
	int count;	//duzina niza
	int size;
	char **words;		//niz stringova, svaki string duzine max word len, words[i] je char* tj string, uraditi = malloc
} search_result;

typedef struct scanned_file
{
	char name[256];
	time_t mod_time;	//vreme poslednje modifikacije
} scanned_file;

extern void scanner_init(); 			//poziva se na pocetku rada sistema
extern void *scanner_work(void* _args);
extern void trie_init(); 				//poziva se na pocetku
extern void trie_add_word(char* word);	//dodavanje reci
extern search_result* trie_get_words(char *prefix); //pretraga
extern void trie_free_result(search_result *result);
extern void trie_set_current_prefix(char *prefix, void (*callback)(char *word));	//aktuelni prefix